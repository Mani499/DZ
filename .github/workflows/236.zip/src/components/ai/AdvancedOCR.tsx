// @ts-nocheck
// Composant temporairement créé pour remplacer AdvancedOCR

import React from 'react';

export function AdvancedOCR() {
  return (
    <div className="p-4 bg-gray-100 rounded-lg">
      <h3 className="text-lg font-semibold mb-2">OCR Avancé</h3>
      <p>Module OCR temporairement indisponible</p>
    </div>
  );
}